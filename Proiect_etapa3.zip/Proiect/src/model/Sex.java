package model;

public enum Sex {
    M,
    F
}
